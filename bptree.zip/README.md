Description:
	insert_temp_after_left_child()
		left_parentからtempにコピーされた後の状態
		rs_keyの入る場所を探す
		それより大きいkeyとpointerを右にシフト
		rs_keyを挿入

	copy_from_temp_to_left_parent(&temp, left_parent);
		tempのkeyの半分をleft_parentにコピー
		コピーしたkeyの両サイドのpointerもコピー

	copy_from_temp_to_right_parent(&temp, right_parent);
		残りのkeyで一番左のもの(rs_key_parent)はさらに上へ上げるので、
		それ以降のpointerとkeyをright_parentにコピー

	


Running Example:

Key: 1
[1]
Key: 2
[1 2]
Key: 3
[1 2 3]
Key: 4
[[1 2]3[3 4]]
Key: 5
[[1 2]3[3 4 5]]
Key: 6
[[1 2]3[3 4]5[5 6]]
Key: 7
[[1 2]3[3 4]5[5 6 7]]
Key: 8
[[1 2]3[3 4]5[5 6]7[7 8]]
Key: 9
[[1 2]3[3 4]5[5 6]7[7 8 9]]
Key: 10
[[1 2]3[3 4]5[5 6]]
[[7 8]9[9 10]]
[[[1 2]3[3 4]5[5 6]]7[[7 8]9[9 10]]]
Key: 13
[[[1 2]3[3 4]5[5 6]]7[[7 8]9[9 10 13]]]
Key: 11
[[[11 13]11[1 2]3[3 4]5[5 6]]7[[7 8]9[9 10]]]
Key:

parentのsplitはうまく出来ましたが、
今度は1~10, 13の後に11を入れてみると、tempまではきちんと出来てましたが、
tempからsplitした後のright_childがなぜか一番前に行って、
rs_keyも一番前に入ってしまうという…
なぜでしょうか><

原因として、380行目以降の
			
		right->chi[N-1] = left->chi[N-1];	
		left->chi[N-1] = right;
		erase_entries(left);
		copy_from_temp_to_left(temp, left);
		copy_from_temp_to_right(temp, right);
		int rs_key = right->key[0]; // right smallest key
		insert_in_parent(left, rs_key, right);
		
において、erase_entries(left); が原因で、
left->chi[N-1] = right; が機能していないのかと思い、
二つの順番を入れ替えて以下のようにしたものの、改善せず。


		right->chi[N-1] = left->chi[N-1];	
		erase_entries(left);
		left->chi[N-1] = right;
		copy_from_temp_to_left(temp, left);
		copy_from_temp_to_right(temp, right);
		int rs_key = right->key[0]; // right smallest key
		insert_in_parent(left, rs_key, right);